export { default as adminService } from './adminService';
