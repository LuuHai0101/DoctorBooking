function a(x) {
    if (x < 10) {
        return x;
    } else {
        if (x < 20) {
            return 21;
        } else {
            if (x < 30) {
                return 31;
            } else {
                return 100;
            }
        }
    }
}

function a(x) {
    const user = getUser();

    if(!user){
       //tra ve loi ko tim thay user
    }
    //thuc thi cau lenh xu ly user
    // line 1
    // line 2
    // line 3



    if(user){
        //thuc thi cau lenh xu ly user
        // line 1
        // line 2
        // line 3
    }else{
        //tra ve loi ko tim thay user
    }

}